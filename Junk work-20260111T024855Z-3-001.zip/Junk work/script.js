// ---------------- MAPS ----------------
const mumbaiMap = L.map("map-mumbai").setView([19.0760, 72.8777], 11);
const delhiMap = L.map("map-delhi").setView([28.6139, 77.2090], 11);

L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  attribution: "© OpenStreetMap"
}).addTo(mumbaiMap);

L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  attribution: "© OpenStreetMap"
}).addTo(delhiMap);


// ---------------- CITY DATA ----------------
const CITY_DATA = {
  mumbai: { name: "Mumbai", lat: 19.0760, lon: 72.8777, coords: [19.0760, 72.8777] },
  delhi: { name: "Delhi", lat: 28.6139, lon: 77.2090, coords: [28.6139, 77.2090] },
  pune: { name: "Pune", lat: 18.5204, lon: 73.8567, coords: [18.5204, 73.8567] },
  bangalore: { name: "Bangalore", lat: 12.9716, lon: 77.5946, coords: [12.9716, 77.5946] }
};


// ---------------- FIREBASE ----------------
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getFirestore, collection, addDoc, onSnapshot } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyCV-FAsdiLUXEeh1OLKGPsdVKchqsEWHX4",
  authDomain: "hackathon-app-b513c.firebaseapp.com",
  projectId: "hackathon-app-b513c",
  storageBucket: "hackathon-app-b513c.appspot.com",
  messagingSenderId: "199251034902",
  appId: "1:199251034902:web:7905a40a9a162ff5cf8637"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);


// ---------------- DOM ----------------
const citySelect = document.getElementById("city");
const weatherBox = document.getElementById("weatherBox");
const aqiBox = document.getElementById("aqiBox");
const complaintBox = document.getElementById("complaintBox");

const searchInput = document.getElementById("citySearch");
const suggestionsBox = document.getElementById("suggestions");
const modal = document.getElementById("cityModal");
const modalTitle = document.getElementById("modalTitle");
const closeModal = document.getElementById("closeModal");

let popupMap = null;


// ---------------- LIVE COMPLAINT COUNT ----------------
onSnapshot(collection(db, "reports"), (snapshot) => {
  complaintBox.innerText = snapshot.size;
});


// ---------------- SUBMIT REPORT ----------------
document.getElementById("submitReport").addEventListener("click", async () => {
  const city = citySelect.value;
  const issueType = document.getElementById("issueType").value;
  const description = document.getElementById("description").value.trim();

  if (!city || !issueType || !description) {
    alert("Please fill all fields");
    return;
  }

  await addDoc(collection(db, "reports"), {
    city,
    issueType,
    description,
    timestamp: new Date()
  });

  const mapRef = city === "mumbai" ? mumbaiMap : delhiMap;
  const coords = CITY_DATA[city].coords;

  L.marker(coords)
    .addTo(mapRef)
    .bindPopup(`<b>${issueType}</b><br>${description}`)
    .openPopup();

  mapRef.flyTo(coords, 13, { animate: true, duration: 1.2 });
});


// ---------------- WEATHER ----------------
async function loadWeather(cityKey) {
  const city = CITY_DATA[cityKey];
  if (!city) return;

  weatherBox.innerText = "Loading...";

  const res = await fetch(
    `https://api.open-meteo.com/v1/forecast?latitude=${city.lat}&longitude=${city.lon}&current_weather=true`
  );

  const data = await res.json();
  const w = data.current_weather;

  weatherBox.innerText = `${city.name}: ${w.temperature}°C • Wind ${w.windspeed} km/h`;
}


// ---------------- AQI ----------------
async function loadAQI(cityKey) {
  const city = CITY_DATA[cityKey];
  if (!city) return;

  aqiBox.innerText = "Loading...";

  const res = await fetch(
    `https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${city.lat}&longitude=${city.lon}&current=pm2_5`
  );

  const data = await res.json();
  const pm25 = data.current.pm2_5;

  let status = "Good";
  if (pm25 > 60) status = "Moderate";
  if (pm25 > 120) status = "Poor";

  aqiBox.innerText = `${city.name}: ${pm25} µg/m³ • ${status}`;
}


// ---------------- CITY DROPDOWN ----------------
citySelect.addEventListener("change", () => {
  const city = citySelect.value;
  loadWeather(city);
  loadAQI(city);
});


// ---------------- SEARCH BAR ----------------
searchInput.addEventListener("input", () => {
  const value = searchInput.value.toLowerCase();
  suggestionsBox.innerHTML = "";

  if (!value) {
    suggestionsBox.style.display = "none";
    return;
  }

  Object.keys(CITY_DATA).forEach(key => {
    if (CITY_DATA[key].name.toLowerCase().includes(value)) {
      const div = document.createElement("div");
      div.innerText = CITY_DATA[key].name;
      div.onclick = () => openCityModal(key);
      suggestionsBox.appendChild(div);
    }
  });

  suggestionsBox.style.display = "block";
});


// ---------------- CITY POPUP MAP ----------------
function openCityModal(cityKey) {
  const city = CITY_DATA[cityKey];

  modalTitle.innerText = city.name;
  modal.style.display = "flex";
  suggestionsBox.style.display = "none";

  setTimeout(() => {
    if (popupMap) popupMap.remove();

    popupMap = L.map("cityMap").setView(city.coords, 11);

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "© OpenStreetMap"
    }).addTo(popupMap);

    L.marker(city.coords).addTo(popupMap);

    popupMap.invalidateSize();   // 🔥 fixes blank/shifted maps
  }, 200);
}

closeModal.onclick = () => {
  modal.style.display = "none";
  if (popupMap) popupMap.remove();
};


// ---------------- DEFAULT LOAD ----------------
citySelect.value = "mumbai";
loadWeather("mumbai");
loadAQI("mumbai");


// ---------------- PAGE REDIRECT ----------------
document.querySelectorAll("[data-page]").forEach(item => {
  item.addEventListener("click", (e) => {
    e.stopPropagation();
    window.location.href = item.getAttribute("data-page");
  });
});


// ---------------- SIDEBAR MENU ----------------
window.addEventListener("load", () => {
  const menuBtn = document.getElementById("menuBtn");
  const sidebar = document.querySelector(".sidebar");

  if (!menuBtn || !sidebar) return;

  menuBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    sidebar.classList.toggle("active");
  });

  document.addEventListener("click", (e) => {
    if (!sidebar.contains(e.target) && !menuBtn.contains(e.target)) {
      sidebar.classList.remove("active");
    }
  });
});
const sidebar = document.querySelector(".sidebar");
const body = document.body;

sidebar.addEventListener("mouseenter", () => {
  body.classList.add("sidebar-open");
});

sidebar.addEventListener("mouseleave", () => {
  body.classList.remove("sidebar-open");
});



