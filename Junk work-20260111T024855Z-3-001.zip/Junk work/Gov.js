const track = document.getElementById("track");
const slides = document.querySelectorAll(".slide");
const prevBtn = document.getElementById("prev");
const nextBtn = document.getElementById("next");

let index = 0;
const AUTO_SLIDE = true;     // change to false if you want manual only
const INTERVAL = 4000;       // 4 seconds
let timer = null;

function showSlide(i) {
  index = (i + slides.length) % slides.length;
  track.style.transform = `translateX(-${index * 100}%)`;
}

// button controls
nextBtn.addEventListener("click", () => {
  showSlide(index + 1);
  restartAuto();
});

prevBtn.addEventListener("click", () => {
  showSlide(index - 1);
  restartAuto();
});

// auto slide (optional)
function startAuto() {
  if (!AUTO_SLIDE) return;
  timer = setInterval(() => {
    showSlide(index + 1);
  }, INTERVAL);
}

function restartAuto() {
  if (!AUTO_SLIDE) return;
  clearInterval(timer);
  startAuto();
}

// init
showSlide(0);
startAuto();
